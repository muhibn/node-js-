export default function Home(){

    return(
        <div className="Home">Home page </div>
    );
}